﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace CrossPlatformDesktopProject
{
    class MovingSprite
    {
        public Texture2D Texture { get; set; }
        public int PosX;
        public MovingSprite(Texture2D texture)
        {
            Texture = texture;
            PosX = 0;
        }
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(Texture, new Rectangle(PosX, 300, 120, 150), Color.White);
            spriteBatch.End();
        }
        public void Update()
        {
            PosX++;
            if (PosX % 480 == 0)
            {
                PosX = 0;
            }
        }
    }
}
