﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace CrossPlatformDesktopProject
{
    class TextSprite
    {
        SpriteFont Font;
        Vector2 FontPos;

        public TextSprite(SpriteFont font, Vector2 fontPos)
        {
            Font = font;
            FontPos = fontPos;
        }
        public void Draw(SpriteBatch spriteBatch, string output)
        {
            Vector2 FontOrigin = Font.MeasureString(output) / 2;
            spriteBatch.DrawString(Font, output, FontPos, Color.White, 0, FontOrigin, 1.0f, SpriteEffects.None, 0.5f);
        }
    }
}
