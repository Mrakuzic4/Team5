﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace CrossPlatformDesktopProject
{
    class StillSprite
    {
        public Texture2D Texture { get; set; }

        public StillSprite(Texture2D texture)
        {
            Texture = texture;
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(Texture, new Rectangle(0, 0, 120, 150), Color.White);
            spriteBatch.End();
        }
        public void Update()
        {
            
        }
    }
}
