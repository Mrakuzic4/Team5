﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrossPlatformDesktopProject
{
    class KeyboardController: IController
    {
        public void Update()
        {
            /* 
            if (Keyboard.GetState().IsKeyDown(Keys.D2))
            {
                AnimatedMario.Update();
            }

            if (Keyboard.GetState().IsKeyDown(Keys.D4))
            {
                MovingMario.Update();
            }
            */
        }
    }
}
